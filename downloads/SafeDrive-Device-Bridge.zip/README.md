# SafeDrive Device Bridge

This Windows companion exposes the vehicle telemetry dashboard at `http://127.0.0.1:3000` and forwards selected synthetic signals to one Android device over ADB.

## Requirements

- Windows PowerShell
- Node.js 18+
- Android Platform Tools (`adb` on PATH)
- One Android device with USB debugging enabled
- SafeDrive APK: Developer Mode → **Nhận dữ liệu từ PC** enabled

## Start

1. Connect exactly one Android device and accept its USB-debugging prompt.
2. Right-click `start_dashboard.ps1` → Run with PowerShell, or run:
   `powershell -ExecutionPolicy Bypass -File .\start_dashboard.ps1`
3. Open `http://127.0.0.1:3000`.
4. Select evidence signals and send them. `VHAL_IMPACT` alone is strong primary evidence; `DEVICE_IMU` requires corroboration such as `VHAL_SPEED_DROP`.

The dashboard is a simulation input. The Android receiver, Crash Evidence Fusion, proactive occupant check and emergency state machine are the product runtime. SOS dispatch remains `SIMULATION_ONLY`.
