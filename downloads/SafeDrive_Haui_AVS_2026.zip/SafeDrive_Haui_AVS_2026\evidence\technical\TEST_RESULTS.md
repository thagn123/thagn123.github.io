# Test Results — 09/08/2026

## Android

Command: `gradlew :app:testDebugUnitTest --no-build-cache --rerun-tasks`

- Suites: 36
- Tests: 364
- Failures: 0
- Errors: 0
- Skipped: 0
- Result: `BUILD SUCCESSFUL`

Command: `gradlew :app:assembleDebug --no-build-cache --rerun-tasks`

- Result: `BUILD SUCCESSFUL`
- Output promoted to `SafeDrive-demo-unified-ac8c804.apk`.

## Backend

Command: `.venv/Scripts/python.exe -m pytest -q` from backend root.

- Result: `355 passed, 1 warning in 23.82s`
- Warning: Starlette/httpx deprecation only; no failed test.
