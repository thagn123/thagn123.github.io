# Kịch bản demo SafeDrive AI — 6 phút

## 0:00–0:30 — Mở bài

“SafeDrive không thay thế LLM. Chúng tôi bổ sung Agent Armor để LLM chỉ diễn đạt dữ liệu xe đã được kiểm chứng, không bịa nguồn, không tự ý điều khiển và vẫn an toàn khi model lỗi.”

Chỉ trạng thái **Remote / Đã kết nối** và CarSky deployment **20/20**.

## 0:30–1:15 — Hiểu context và trả lời có chứng cứ

Giữ telemetry đang phát. Hỏi: “Xe của tôi hiện tại thế nào, có gì cần chú ý không?”

Trên evidence console chỉ các trường: `route=assistant.vehicle_status`, `llmUsed=true`, `model=vertex_ai/gemini-2.5-flash`, risk/reason codes. Nói: “Vertex diễn đạt; nguồn, freshness và risk do Armor khóa.”

## 1:15–2:05 — Điều khiển có thẩm quyền

Nói “Lạnh quá” → proposal HVAC 26°C → xác nhận. Cho thấy action token và trạng thái sau confirm. Có thể chuyển nhanh sang cửa/media để cho thấy mọi executor dùng chung Action Authority.

Nói rõ: phone mô phỏng effect; AAOS tương thích dùng VHAL/Android Media và read-back.

## 2:05–2:50 — Chống hành động sai ngữ cảnh

Tạo proposal HVAC, tăng nhiệt động cơ trên 115°C rồi xác nhận proposal cũ.

Phải thấy: `accepted=false`, HVAC không đổi, không toast thành công. Chốt: “Context thay đổi làm fingerprint hết hiệu lực; LLM không thể lách bằng lời.”

## 2:50–3:35 — Chủ động cảnh báo và nhớ context

Đẩy engine WARNING/HIGH, rồi thêm fatigue/driver signal. App cảnh báo trước khi bị hỏi. Hỏi tiếp “Tại sao?” để chứng minh context continuity và memory. Chỉ source, freshness và reason codes.

## 3:35–5:05 — E2E SOS: public WebADB → app tự hành động

1. Giữ điện thoại ở Cockpit/Assistant; không chạm micro.
2. Mở `https://safedrive-haui-avs.daothangclash2803200.chatgpt.site/device-bridge` bằng Chrome/Edge, kết nối USB và chấp nhận RSA. Gửi `HIGH_SPEED` đơn lẻ: không mở SOS.
3. Chọn duy nhất `VHAL_IMPACT`, bấm gửi rồi bỏ tay khỏi điện thoại.
4. App phải tự phủ màn SOS, hiển thị `BƯỚC 1/3`, chip **Va chạm VHAL**, `Reason codes: vhal_impact`, tốc độ hiện tại.
5. Sau xác minh, app chuyển `BƯỚC 2/3`, tự nói “Bạn có ổn không?” và tự mở micro. Không có câu hỏi chat, không có thao tác bấm nghe.
6. Nói “Tôi ổn” để chứng minh người dùng có quyền hủy; hoặc im lặng để trình diễn `FINAL_COUNTDOWN` → `SOS_SIMULATED_SENT`.

Câu chốt: “Dashboard chỉ gửi bằng chứng. Crash Fusion quyết định, Emergency state machine chuyển bước, TTS/STT chủ động kiểm tra; LLM chỉ được phép giải thích bổ sung và không được chạm deadline.”

Chỉ ngay **Action receipt** trên web: WebUSB permission → ADB authenticated → APK package verified → broadcast exit/result. Sau đó đối chiếu với chip nguồn, reason code và state trên APK. Đây là chuỗi chứng cứ input–decision–outcome, không phải chỉ quay màn hình kết quả.

Luôn nói rõ: cứu hộ là **SIMULATION_ONLY**, `realDispatch=false`.

## 5:05–5:40 — Chứng thực Agent Armor

Mở bảng live matrix 13/13 và chỉ ba dòng:

- Vehicle status: `llmUsed=true`, Vertex, response có route/model.
- Stale action khi CRITICAL: `accepted=false`, canonical HVAC không đổi.
- Câu hỏi phức hợp: Vertex được dùng nhưng `actions=0`.

Nói: “LLM suy luận ngôn ngữ trong ranh giới Armor. Risk, grounding, quyền hành động và SOS là deterministic; mọi phản hồi có metadata để audit.”

## 5:40–6:00 — Kết

“Giá trị của SafeDrive không nằm ở một model cụ thể. Giá trị nằm ở lớp bảo đảm để Ollama, Gemini hay Vertex AI đều trở thành trợ lý ô tô chắc chắn, chủ động và có trách nhiệm.”

## Checklist trước demo

- Điện thoại mở khóa; app Remote; RECORD_AUDIO đã cấp; TTS tiếng Việt READY.
- BASE_URL production; Cockpit hiện kết nối.
- Public USB Device Bridge hiện ADB authenticated và xác minh package SafeDrive. Dashboard port 3000 chỉ là phương án dự phòng của đội.
- Telemetry heartbeat hoạt động; khoảng cách chat dưới 10 giây.
- Xóa emergency demo cũ và chạy một dry-run hoàn chỉnh.
- Không redeploy Cloud Run/CarSky sát giờ thi.
- Mở sẵn screenshots `10 → 08 → 07` và live matrix nếu mạng sân khấu lỗi.
