# Hybrid LLM runtime — verified status

## 1. Cloud production — VERIFIED

- Cloud Run revision: `safedrive-backend-00015-kfj`, 100% traffic, `minScale=1`.
- Runtime source: `ac8c804831b9a4991e4ed46625b458c6d5fc95d0`.
- Provider/model: `vertex_ai/gemini-2.5-flash`.
- Context memory: Firestore.
- Live production matrix on 2026-08-09: **13/13 PASS**.

## 2. Local edge development host — VERIFIED

- Host: Windows laptop running the SafeDrive backend and Ollama locally.
- Provider/model: `ollama/qwen2.5:7b-instruct-q4_K_M` at `127.0.0.1:11434`.
- Backend: `127.0.0.1:8000`; Android may reach it through `adb reverse tcp:8000 tcp:8000`.
- Live local matrix on 2026-08-09: **13/13 PASS**, including grounded status, action confirmation/replay rejection, stale-action rejection, DTC honesty, fatigue, crash fusion, deterministic SOS, guarded complex query and WebSocket parity.
- Laptop role: **edge development host + ADB Device Bridge**. It is not claimed to be an automotive ECU or embedded target.

## 3. Jetson / in-vehicle edge — COMPATIBLE TARGET, NOT YET DEVICE-VERIFIED

SafeDrive separates the deterministic Armor from the narration provider. The existing `OllamaNarrator`, `OllamaIntentClassifier` and bounded emergency reasoner use an HTTP Ollama endpoint and a quantized Qwen model. Therefore the same Linux-compatible backend/provider boundary can be deployed on a Jetson-class device without changing Risk Engine, Grounding, Action Authority, Context Memory or the Emergency state machine.

What is proven now: the complete local/Ollama flow and 13/13 matrix on an edge development host.

What remains before claiming “running on Jetson”: build/install on the chosen Jetson, record model load and latency, run the same 13/13 matrix, and capture resource/thermal measurements.

## Presenter-safe claim

> SafeDrive is cloud-capable and edge-portable. Production uses Vertex AI; the same Agent Armor has been verified end-to-end with local Ollama/Qwen. Jetson is our compatible embedded deployment target, not a completed hardware claim yet.
