# Public WebADB Judge Flow

## Mục tiêu

Giám khảo chỉ tải một APK. Dashboard được host công khai tại:

`https://safedrive-haui-avs.daothangclash2803200.chatgpt.site/device-bridge`

Không cần tải Node.js, Android Platform Tools hay gói dashboard port 3000.

## Chuỗi end-to-end có thể đối chiếu

| Mốc | Bằng chứng hiển thị | Điều được chứng minh |
|---|---|---|
| 1. WebUSB permission | Hộp chọn thiết bị của Chrome/Edge | Trình duyệt chỉ truy cập thiết bị người dùng chủ động chọn |
| 2. ADB authentication | Android hiển thị khóa RSA; web hiện model/Android version | Phiên ADB thật đã được thiết lập trực tiếp với thiết bị |
| 3. Package verification | `pm path vn.edu.haui.hvs.safedrive` thành công | Đúng APK SafeDrive đang có trên thiết bị |
| 4. Telemetry broadcast | Action receipt có package, speed, heart rate, signals, exit/result | Input đã được gửi vào đúng receiver, không phải animation web |
| 5. Crash fusion | APK hiện chip nguồn và `Reason codes: vhal_impact` | App đọc nguồn/context và policy deterministic kết luận candidate |
| 6. Proactive check | APK tự chuyển VERIFYING, TTS hỏi và STT `vi-VN` tự mở | App chủ động kiểm tra, không yêu cầu chat hoặc bấm micro |
| 7. Emergency outcome | `FINAL_COUNTDOWN → SOS_SIMULATED_SENT` cùng runtime log | State machine thực thi tiến trình; dispatch cứu hộ vẫn là mô phỏng |

## Hai đường chạy

### A. Điện thoại Android — đường chính thức cho giám khảo

1. Cài `SafeDrive-demo-unified-ac8c804.apk`.
2. Bật Developer options và USB debugging.
3. Mở link bằng Chrome/Edge desktop, cắm USB, bấm kết nối.
4. Chọn thiết bị và chấp nhận RSA trên điện thoại.
5. Gửi `HIGH_SPEED` riêng để chứng minh không false-positive; sau đó gửi `VHAL_IMPACT` để chứng minh luồng khẩn cấp.

### B. CarSky/AAOS — đường platform

WebADB dùng được nếu IVI/node Android của CarSky xuất giao diện ADB qua USB tới máy đang mở trình duyệt. Nếu môi trường CarSky chỉ cho ADB qua cổng/console của platform, dùng đường CarSky hiện có và dashboard local của đội. Không tuyên bố link web có thể điều khiển từ xa một node CarSky không nối USB.

## Bảo mật và giới hạn

- Lệnh được tạo từ allowlist gồm 6 crash signals và trường tốc độ/nhịp tim có giới hạn; không có terminal tùy ý trong UI.
- USB traffic chạy giữa trình duyệt và thiết bị; không upload dữ liệu ADB lên site.
- Chrome/Edge desktop là đường được hỗ trợ. WebUSB yêu cầu HTTPS và user gesture.
- Một ADB interface chỉ có thể bị một client giữ; đóng Android Studio/ADB khác nếu gặp `device busy`.
- Source telemetry là mô phỏng; Android receiver, fusion, TTS/STT, state machine và UI là runtime thật. SOS dispatch là `SIMULATION_ONLY`.
