# SafeDrive AI — Hồ sơ nộp bài Automotive Hackathon 2026

**Đội:** Haui AVS  
**Bản phát hành:** `ac8c804831b9a4991e4ed46625b458c6d5fc95d0`  
**Ngày đóng gói:** 09/08/2026

## Mở theo thứ tự

1. `01_SafeDrive_Submission_Report.pdf` — hồ sơ trình bày chính.
2. `02_DEMO_SCRIPT.md` — kịch bản demo 6 phút và checklist trước sân khấu.
3. `03_EVIDENCE_MATRIX.md` — claim, kết quả quan sát và vị trí bằng chứng.
4. `04_TECHNICAL_MANIFEST.md` — SHA, endpoint, revision, checksum và cấu hình chạy.
5. `05_LIMITATIONS_AND_CLAIMS.md` — phạm vi được phép tuyên bố.
6. `apk/SafeDrive-demo-unified-ac8c804.apk` — APK nộp bài.

## Liên kết

- Trải nghiệm công khai: https://safedrive-haui-avs.daothangclash2803200.chatgpt.site
- USB Device Bridge cho giám khảo: https://safedrive-haui-avs.daothangclash2803200.chatgpt.site/device-bridge
- Tải APK trực tiếp: https://safedrive-haui-avs.daothangclash2803200.chatgpt.site/downloads/SafeDrive-demo-unified-ac8c804.apk
- Mã nguồn: https://github.com/thagn123/SafeDrive
- Backend production: https://safedrive-backend-165374511912.asia-southeast1.run.app
- CarSky: artifact `safedrive-apk`, version `0.0.6` (`latest`).

## Trạng thái khóa release

- Android unit: **364/364 passed**.
- Backend: **355/355 passed**.
- APK: build và cài cập nhật thành công trên Xiaomi.
- Cloud Run: `safedrive-backend-00015-kfj`, 100% traffic, `minScale=1`.
- LLM: Vertex AI `gemini-2.5-flash`; Context Memory: Firestore.
- Edge local: Ollama `qwen2.5:7b-instruct-q4_K_M`, live matrix **13/13 passed**; Jetson là đích tương thích, chưa device-verified.
- CarSky deployment: `Haui AVS-deploydeployment-1`, **Running 20/20**; APK mới nằm ở artifact 0.0.6.

Không đưa file tài khoản/mật khẩu CarSky vào gói nộp.

## Luồng trải nghiệm tối giản cho giám khảo

1. Tải và cài duy nhất APK ở link trên.
2. Trên Chrome/Edge desktop, mở **USB Device Bridge**, cắm điện thoại Android, bật USB debugging.
3. Bấm **Kết nối USB bằng WebADB**, chọn thiết bị và chấp nhận khóa RSA trên Android.
4. Chọn `VHAL_IMPACT`, bấm gửi; quan sát APK tự chuyển `VERIFYING`, chủ động TTS/STT và đi tới `SOS_SIMULATED_SENT` nếu không có lệnh hủy hợp lệ.

Dashboard local port 3000 vẫn có trong gói dự phòng của đội, nhưng **không phải điều kiện để giám khảo trải nghiệm**.
