# Agent Armor — chuỗi chứng minh

## 1. Perception có nguồn và độ mới

Telemetry được chuẩn hóa thành context có source, timestamp, freshness và status. Crash Evidence Adapter phân biệt VHAL impact, airbag, IMU, speed drop, high speed và sensor fault. Context cũ không được dùng như dữ kiện hiện tại.

## 2. Judgment deterministic

Risk Engine, Crash Evidence Fusion, intent routing và Action Authority quyết định mức rủi ro, reason code, hành động cho phép và emergency transition. LLM không đặt ngưỡng, không tạo action token và không tự chuyển state SOS.

## 3. Narration bị giới hạn

LLM nhận phần trả lời đã duyệt cùng grounded context, không nhận quyền thay đổi quyết định. Grounding kiểm tra số liệu/đơn vị/snippet; token không xác minh bị chặn. HIGH/CRITICAL có thể đi thẳng template deterministic. Nếu provider lỗi, hệ thống trả fallback có kiểm soát.

## 4. Output kiểm toán được

Mỗi phản hồi mang metadata như route, risk, reason codes, actions, `llmUsed`, model và fallback. Action confirm còn kiểm tra target, dependency fingerprint, freshness và replay. Vì vậy có thể chứng minh câu trả lời đến từ context nào và vì sao hành động được chấp nhận hay từ chối.

## Phạm vi chính xác của tuyên bố

SafeDrive không khẳng định LLM tự quyết định an toàn. LLM suy luận về ngôn ngữ và yêu cầu người dùng **bên trong ranh giới của Armor**; các sự thật, mức rủi ro, quyền hành động và SOS do các lớp deterministic xác lập. Đây là điểm nâng cấp: có thể thay Ollama/Gemini/Vertex AI mà không xây lại Risk Engine, Grounding, Action Authority, Context Memory hay Emergency state machine.

## Bằng chứng thực thi

- Production matrix: `LIVE_ARMOR_MATRIX_2026-08-09.md` — 13/13 PASS.
- Dashboard → Android → SOS: `E2E_SOS_PORT3000.md`.
- Ảnh UI: `../screenshots/10_dashboard_vhal_impact_input.png`, `../screenshots/08_dashboard_to_sos_verifying.png`, `../screenshots/07_sos_simulated_sent.png`.
- Test tổng: Android 364/364; backend 355/355.
- Hai runtime LLM độc lập đã vượt cùng ma trận: Cloud Vertex AI 13/13 và local Ollama/Qwen 13/13. Xem `HYBRID_LLM_RUNTIME.md`.
