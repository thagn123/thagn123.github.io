# Evidence Matrix

| Claim | Expected | Observed | Status | Evidence locator | Caveat |
|---|---|---|---|---|---|
| Giám khảo chỉ cần APK + link công khai | Browser kết nối trực tiếp USB/ADB, không cài dashboard PC | `/device-bridge` build/test xanh; có package verification, allowlist tín hiệu và broadcast receipt | Real implementation / hardware permission requires user gesture | `screenshots/15_public_webadb_judge_bridge.jpg`; `technical/PUBLIC_WEBADB_JUDGE_FLOW.md` | Chrome/Edge desktop; người dùng phải chọn USB và chấp nhận RSA |
| Android release ổn định | Full unit suite xanh | 364/364, 0 failure; APK build thành công | Real | `evidence/technical/TEST_RESULTS.md` | Unit/JVM; không thay thế test lái xe thực tế |
| Backend Agent Armor ổn định | Full suite xanh | 355/355; Ruff sạch | Real | `evidence/technical/TEST_RESULTS.md` | 1 deprecation warning không ảnh hưởng runtime |
| Vertex AI production | Model được gọi và có fallback | `llmUsed=true`, `model=vertex_ai/gemini-2.5-flash`; outage/recovery sạch | Real | `evidence/technical/VERTEX_AI_VERIFICATION.md`; `LIVE_ARMOR_MATRIX_2026-08-09.md` | Model narrate context đã duyệt, không ra quyết định an toàn |
| Phản hồi có thể chứng thực | Có metadata để đối chiếu câu trả lời | route/risk/reasonCodes/actions/llmUsed/model/fallback; live 13/13 PASS | Real | `evidence/technical/LIVE_ARMOR_MATRIX_2026-08-09.md`; `ARMOR_PROOF_CHAIN.md` | Không đánh đồng lời văn LLM với quyết định máy |
| Hybrid Cloud/Edge | Cùng Armor chạy với Vertex AI và Ollama | Cloud 13/13; local Ollama/Qwen 13/13 | Real | `evidence/technical/HYBRID_LLM_RUNTIME.md` | Laptop là edge development host; Jetson mới là target, chưa device-verified |
| Context Memory lưu bền | Memory production là Firestore | Cloud env `MEMORY_BACKEND=firestore`; fact có TTL/source | Real | `evidence/technical/CLOUD_RUNTIME.md` | TTL áp dụng theo loại fact |
| HVAC cần xác nhận | Proposal trước khi thực thi | Proposal 26°C; confirm token qua Action Authority | Real flow / simulated effect trên phone | `screenshots/04_hvac_proposal.png` | VHAL thật phụ thuộc property/quyền AAOS |
| Đề xuất cũ bị khóa | Context CRITICAL làm confirm cũ bị từ chối | accepted=false; HVAC không đổi; replay/tamper bị chặn | Real backend + device UI | `screenshots/05_stale_action_rejected.png`; live matrix UC3–4 | UI evidence thuộc release lineage |
| HVAC / cửa / media thật | Executor gọi VHAL/Android media và read-back | AAOS instrumentation `OK (1 test)` | Partial/Real on compatible AAOS | Báo cáo chính, mục Vehicle Actions | Node phải công bố property và cấp quyền |
| App đọc bằng chứng crash | Hiển thị nguồn, reason code, context | Chip VHAL sáng; `Reason codes: vhal_impact`; tốc độ 62 km/h | Real Android runtime / simulated source | `screenshots/12_phone_vhal_impact_verifying_ac8c804.png`; `evidence/technical/E2E_SOS_PORT3000.md` | Port 3000 là bộ phát telemetry demo |
| Crash Evidence Fusion | Nhiễu đơn không tạo SOS; strong/corroborated mới mở candidate | Noisy evidence giữ IDLE; VHAL impact mở VERIFYING | Real policy + live matrix | `LIVE_ARMOR_MATRIX_2026-08-09.md`; `E2E_SOS_PORT3000.md` | Không tuyên bố phone có VHAL vật lý |
| Kiểm tra người trong xe chủ động | App tự hỏi và tự nghe, không chờ người dùng chat/bấm mic | TTS occupant-check thành công; SpeechRecognizer tự start `vi-VN` | Real Xiaomi device | `screenshots/13_phone_proactive_occupant_check_ac8c804.png`; `evidence/technical/PHONE_E2E_RUNTIME_LOG_AC8C804.txt` | Micro cần quyền RECORD_AUDIO |
| SOS state machine | Sensor → verify → hỏi/nghe → countdown → send | Release ac8c804 chạy trên Xiaomi từ VERIFYING tới SOS_SIMULATED_SENT | Real state machine / simulated dispatch | `E2E_SOS_PORT3000.md`; screenshots `11`–`14` | `SIMULATION_ONLY`, không gọi cứu hộ thật |
| CarSky utilization | Có deployment/artifact/IVI | Running 20/20; SafeDrive mở trong IVI Screen; HvacCommand signals hiển thị; artifact 0.0.6 latest | Real platform | `screenshots/01_carsky_deployment_20_of_20.png`; `17_carsky_ivi_safedrive_open.png`; `02_carsky_artifact_0.0.6.png` | AI backend chạy hybrid trên GCP |
| APK nộp khớp release | Filename/SHA/checksum rõ ràng | APK release mới được đóng gói và SHA-256 ghi trong manifest | Real | `04_TECHNICAL_MANIFEST.md`; `checksums.sha256` | Debug-signed hackathon APK |
| Cài trên Xiaomi | Update install thành công | ADB `Success`; proactive TTS/STT đã chạy trên thiết bị | Real | `DEVICE_INSTALL.txt`; `PROACTIVE_OCCUPANT_CHECK_DEVICE.md` | Xiaomi không có Car Service/VHAL |

## Từ vựng trạng thái dùng khi trình bày

- **Real:** chạy trên backend/cloud/platform/thiết bị thật trong phạm vi ghi rõ.
- **Partial:** implementation thật nhưng cần property, quyền hoặc phần cứng tương ứng.
- **Mock/Simulated:** tín hiệu/actuator được bơm mô phỏng; vẫn đi qua pipeline production.
- **Planned:** chưa có trong bản nộp; không được trình bày như đã hoàn thiện.
