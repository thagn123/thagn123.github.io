# VIDEO DEMO — REQUIRED BEFORE SUBMISSION

BTC yêu cầu video/evidence. Gói này chưa có file video gốc trong repository nên không tạo video giả từ ảnh tĩnh.

Quay theo `02_DEMO_SCRIPT.md`, độ dài mục tiêu 5–6 phút. Tên đề nghị:

`SafeDrive_Haui_AVS_Demo_2026.mp4`

Sau khi quay:

1. Chép video vào thư mục gốc của gói này.
2. Điền timestamp vào cột “Video timestamp” của evidence matrix nếu form yêu cầu.
3. Tính SHA-256 và thêm vào `checksums.sha256`.
4. Mở lại video từ đầu đến cuối trước khi submit.
