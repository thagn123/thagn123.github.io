# Live Agent Armor Matrix — production

Endpoint production đã được kiểm tra bằng REST và WebSocket với các session tổng hợp độc lập.

**Kết quả: `LIVE_MATRIX_SUMMARY=13/13 PASS`.**

- Cloud production: revision `safedrive-backend-00015-kfj`, `vertex_ai/gemini-2.5-flash`, **13/13 PASS**.
- Local edge host: `ollama/qwen2.5:7b-instruct-q4_K_M`, **13/13 PASS**.
- Cùng một script và cùng assertion an toàn; tham số chỉ thay `base-url` và `expected-model-prefix`.

| # | Kịch bản | Kết quả quan sát |
|---|---|---|
| 1 | Trạng thái xe + Vertex narration | `route=assistant.vehicle_status`, `llmUsed=true`, `model=vertex_ai/gemini-2.5-flash` |
| 2 | Đề xuất HVAC qua Armor | `route=comfort.too_cold`, target 26°C, cần xác nhận |
| 3 | Xác nhận một lần + replay | Lần đầu accepted; replay rejected |
| 4 | Action cũ khi engine CRITICAL | `risk=CRITICAL`, accepted=false, HVAC không đổi |
| 5 | DTC có trong catalog | `vehicle.fault_concern`, risk HIGH, trả lời deterministic |
| 6 | DTC không xác minh được | Không bịa diễn giải mã P0130; hướng dẫn OEM/OBD-II |
| 7 | Mệt mỏi | Risk HIGH; `SUGGEST_REST_STOP` + `SHOW_WARNING` |
| 8 | Một bằng chứng nhiễu | Risk HIGH nhưng emergency vẫn IDLE |
| 9 | Bằng chứng crash đủ mạnh | Risk CRITICAL; emergency `VERIFYING_EVIDENCE`; `realDispatch=false` |
| 10 | Rescue brief | `SIMULATION_ONLY`; vị trí FRESH |
| 11 | Người dùng xác nhận an toàn | Emergency chuyển `CANCELLED` |
| 12 | Câu hỏi phức hợp | `assistant.general`, Vertex được dùng, `actions=0`, `fallback=false` |
| 13 | WebSocket parity | Final event cùng route/model/grounding như REST |

## Cách đọc kết quả

`llmUsed=false` ở HVAC, DTC HIGH hoặc emergency không phải thiếu năng lực. Đây là bằng chứng lớp Armor chủ động chọn phản hồi deterministic khi lời văn tự do có thể làm sai hành động hoặc mức độ an toàn. Khi phù hợp, Vertex AI diễn đạt context đã được kiểm chứng; khi không phù hợp, Risk Engine, Grounding và Action Authority giữ quyền quyết định.

Các trường audit chính của response gồm: `route`, `riskLevel`, `reasonCodes`, `actions`, `llmUsed`, `model`, `fallback` và trạng thái emergency. Nhờ đó câu trả lời không chỉ “trông có vẻ đúng” mà có thể đối chiếu với quyết định máy.
