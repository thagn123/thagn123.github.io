# Phạm vi claim và giới hạn công khai

## Được phép khẳng định

- Agent Armor tách LLM khỏi quyết định safety/action/emergency; thay model không cần xây lại các lớp này.
- Vertex AI đang chạy production và Context Memory dùng Firestore.
- Ollama/Qwen chạy local trên edge development host và đã vượt cùng ma trận 13/13 như Cloud.
- HVAC, door lock và media có executor thật cho AAOS/Android Automotive; mọi hành động đi qua xác nhận và Action Authority.
- Crash Evidence Adapter lấy dữ liệu từ `IMPACT_DETECTED`, `SEAT_AIRBAGS_DEPLOYED`, `PERF_VEHICLE_SPEED`, `ULTRASONICS_SENSOR_MEASURED_DISTANCE` và accelerometer thiết bị khi có.
- Fusion không dùng `HIGH_SPEED` hoặc lỗi cảm biến đứng riêng để kết luận tai nạn; mục tiêu là giảm false positive.
- CarSky được dùng cho blueprint/deployment/IVI/artifact; GCP được dùng cho AI backend theo kiến trúc hybrid.

## Phải nói rõ điều kiện

- **Public USB Device Bridge** cần Chrome/Edge desktop, HTTPS, USB debugging, thao tác chọn thiết bị và xác nhận khóa RSA. Nếu Android Studio/`adb.exe` đang giữ interface, phải đóng tiến trình đó hoặc chạy `adb kill-server` trước.
- **CarSky qua public WebADB** chỉ dùng được khi node Android/IVI được nối USB trực tiếp vào máy giám khảo và công khai giao diện ADB. Luồng chính thức dễ tái hiện nhất là điện thoại Android; CarSky vẫn là bằng chứng platform riêng.
- **Điều khiển xe thật** chỉ hoạt động khi AAOS công bố property tương ứng và cấp quyền. Trên Xiaomi, actuator là mô phỏng.
- **Phát hiện va chạm vật lý** phụ thuộc nguồn mà thiết bị/xe thực sự cung cấp. Developer Panel bơm tín hiệu mô phỏng nhưng đi qua cùng pipeline fusion.
- **SOS dispatch** là `SIMULATION_ONLY`; sản phẩm không gọi tổng đài cứu hộ thật trong bản hackathon.
- Ảnh stale-action là evidence từ emulator của release lineage; logic tương ứng vẫn nằm trong backend production và test suite hiện tại.
- APK là debug-signed cho hackathon, chưa phải bản phát hành Play Store/OEM production.
- Laptop hiện là edge development host + ADB Device Bridge, không phải ECU. Jetson là đích triển khai tương thích; chưa được phép nói “đã chạy trên Jetson” khi chưa có log/ảnh/benchmark từ phần cứng đó.

## Chưa được xem là hoàn tất nếu thiếu

- Video demo cuối có timestamp và giọng thuyết trình.
- Artifact CarSky 0.0.6 là bằng chứng platform hiện có; APK unified `ac8c804` đã được cài và kiểm tra trực tiếp trên Xiaomi. Nếu artifact chưa được thay bằng APK này, phải nói rõ hai lineage khi trình bày.
