# E2E SOS — Port 3000 → Android → Emergency state machine

## Kết luận

Luồng đã được chạy thật trên máy Windows và điện thoại Xiaomi. Dashboard tại `http://127.0.0.1:3000` chỉ bơm **bằng chứng cảm biến**; nó không gọi màn hình SOS. Ứng dụng Android tự nhận broadcast, hợp nhất bằng chứng, tạo một emergency session, chuyển UI sang bước xác minh và tiến triển tới trạng thái gửi SOS mô phỏng.

## Lần chạy xác nhận release `ac8c804` — 13:36, 09/08/2026

1. Reset về telemetry bình thường 45 km/h: ảnh `../screenshots/11_phone_runtime_normal_ac8c804.png` cho thấy app đang foreground trên Xiaomi và trạng thái `BÌNH THƯỜNG`.
2. Gửi `{"speed":62,"crashSignals":"VHAL_IMPACT"}` vào port 3000: server trả `success=true`, ADB broadcast `result=0`; log ghi `SafeDriveADB: telemetry_applied` lúc `13:36:33.556`.
3. App tự chuyển sang `BƯỚC 1/3`, hiển thị đúng chip `Va chạm VHAL`, tốc độ 62 km/h và `Reason codes: vhal_impact`: ảnh `../screenshots/12_phone_vhal_impact_verifying_ac8c804.png`.
4. App tự phát câu `SafeDrive đang chủ động kiểm tra. Bạn có ổn không?`; `engine.speak() result=0` lúc `13:36:38.647`. Sau đó app tự mở SpeechRecognizer, `callingApp=vn.edu.haui.hvs.safedrive`, `locale=vi-VN`, chuyển `LISTENING` lúc `13:36:44.917`: ảnh `../screenshots/13_phone_proactive_occupant_check_ac8c804.png` và log `PHONE_E2E_RUNTIME_LOG_AC8C804.txt`.
5. Không nhận được câu hủy hợp lệ, state machine hoàn tất ở màn `Đã gửi tín hiệu SOS mô phỏng khẩn cấp`: ảnh `../screenshots/14_phone_sos_simulated_sent_ac8c804.png`. UI nói rõ không có cuộc gọi/tin nhắn thật.

Đây là chuỗi ảnh mới chụp trực tiếp từ APK unified `ac8c804`, không phải ảnh kế thừa từ release cũ.

## Chuỗi bằng chứng

| Bước | Quan sát kiểm chứng được |
|---|---|
| 1. Nguồn vào | Dashboard có ADB Connected; chỉ `VHAL_IMPACT` được chọn. Ảnh: `../screenshots/10_dashboard_vhal_impact_input.png`. |
| 2. Yêu cầu | `POST http://127.0.0.1:3000/api/telemetry` với body `{"crashSignals":"VHAL_IMPACT"}`. |
| 3. Server/ADB | Phản hồi `success=true`; output xác nhận broadcast hoàn tất với `result=0`. |
| 4. Android nhận | Log thiết bị ghi `SafeDriveADB: telemetry_applied` tại `08-09 10:36:00.484`. |
| 5. Armor diễn giải | Emergency snapshot tạo `emergencyId=emg_a5a363d5-ab38-472b-9ef9-55f481baa974`, `state=VERIFYING_EVIDENCE`, evidence code `vhal_impact`. |
| 6. UI tự chuyển | App hiển thị `BƯỚC 1/3: XÁC MINH BẰNG CHỨNG CẢM BIẾN`, chip VHAL sáng, tốc độ 62 km/h và `Reason codes: vhal_impact`. Ảnh: `../screenshots/08_dashboard_to_sos_verifying.png`. |
| 7. Chủ động kiểm tra | Khi vào `AWAITING_USER_RESPONSE`, app tự phát TTS occupant-check rồi tự mở SpeechRecognizer `vi-VN`; không chat và không bấm micro. Locator: `PROACTIVE_OCCUPANT_CHECK_DEVICE.md`. |
| 8. State machine | Cùng `emergencyId` tiến tới `SOS_SIMULATED_SENT`; evidence không bị thay đổi, `deadlineMs=null`. Ảnh: `../screenshots/07_sos_simulated_sent.png`. |
| 9. Giới hạn trung thực | UI ghi `MÔ PHỎNG`; snapshot có `realDispatch=false`. Không tuyên bố gọi cứu hộ thật. |

## Snapshot đã quan sát

```json
{
  "emergencyId": "emg_a5a363d5-ab38-472b-9ef9-55f481baa974",
  "state": "VERIFYING_EVIDENCE",
  "evidence": [
    {
      "code": "vhal_impact",
      "label": "Cảm biến va chạm của xe (VHAL) ghi nhận tác động trực tiếp"
    }
  ],
  "detectedAtMs": 1786246560484
}
```

Sau đó:

```json
{
  "emergencyId": "emg_a5a363d5-ab38-472b-9ef9-55f481baa974",
  "state": "SOS_SIMULATED_SENT",
  "deadlineMs": null,
  "realDispatch": false
}
```

## Điều bằng chứng này chứng minh

- App đọc được **loại nguồn** (`VHAL_IMPACT`), không chỉ một cờ `crash=true` chung chung.
- Quyết định SOS đi qua Crash Evidence Fusion và Emergency state machine của sản phẩm.
- App tự thực hiện kiểm tra người trong xe bằng TTS → STT trong cửa sổ phản hồi; đây không phải một câu khuyến nghị thụ động.
- UI giải thích quyết định bằng chip nguồn, reason code, tốc độ và bước trạng thái.
- Dashboard là bộ phát telemetry phục vụ demo; luồng nhận, fusion, state và UI là luồng runtime Android thật.
