# Proactive occupant check — device evidence

## Kết luận

Đây là hành động tự động của app, không phải lời khuyên “hãy kiểm tra”. Sau khi nhận bằng chứng `VHAL_IMPACT`, emergency reducer chuyển tới `AWAITING_USER_RESPONSE`; SafeDrive tự phát câu hỏi bằng TTS và tự mở SpeechRecognizer để nghe câu trả lời “Tôi ổn”. Người trình diễn không gửi câu hỏi chat và không bấm nút microphone.

## Dấu thời gian quan sát trên Xiaomi

```text
08-09 10:53:17.565 I/SafeDriveADB: telemetry_applied
08-09 10:53:22.610 D/SafeDriveVoiceDebug: [TTS] speak() called:
  id=tts_occupant_check_607171f6-5105-4296-a0c4-f7ef89f08265
  text='SafeDrive đang chủ động kiểm tra. Bạn có ổn không?'
08-09 10:53:22.611 D/SafeDriveVoiceDebug: [TTS] engine.speak() result=0 (SUCCESS=0)
08-09 10:53:29.187 I/RecognitionServiceImpl: RecognitionService#onStartListening
08-09 10:53:29.188 I/RecognitionServiceImpl: callingApp=vn.edu.haui.hvs.safedrive, locale=vi-VN
08-09 10:53:29.193 I/NetworkSpeechRecognizer: Online recognizer - start listening
08-09 10:53:29.194 I/SodaSpeechRecognizer: Offline recognizer - start listening
```

## Ràng buộc an toàn

- Chỉ state `AWAITING_USER_RESPONSE` được phép khởi động kiểm tra bằng giọng nói.
- `collectLatest` hủy hand-off TTS → microphone nếu state chuyển sang USER_OK/CANCELLED/countdown.
- LLM không tham gia mở micro, đổi deadline hay gửi SOS.
- Nếu không có phản hồi, state machine deterministic tiếp tục `FINAL_COUNTDOWN` → `SOS_SIMULATED_SENT`.
- Việc gửi cứu hộ vẫn là `SIMULATION_ONLY`, `realDispatch=false`.

## Gate tự động

- Unit policy mới: `EmergencyProactiveCheckPolicyTest`.
- Android full unit suite: 364/364 sau thay đổi.
- APK build thành công và đã update-install trên Xiaomi.
