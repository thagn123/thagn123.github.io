# Technical Manifest

## Source release

- Branch: `main`
- Git SHA: `ac8c804831b9a4991e4ed46625b458c6d5fc95d0`
- Repository: `https://github.com/thagn123/SafeDrive.git`
- Commit: `fix(safety): proactively verify occupants with bounded voice`

## Android artifact

- File: `apk/SafeDrive-demo-unified-ac8c804.apk`
- Size: `20,980,636` bytes
- SHA-256: `05832A38DD2FD2079201CF1D35B38ECFC4F797B127512F90925A22C7FF713E7F`
- Package: `vn.edu.haui.hvs.safedrive`
- Version: `0.1.0-mvp` (`versionCode=1`)
- CarSky artifact: `safedrive-apk` / `0.0.6` / `latest`

## Public judge experience

- Product site: `https://safedrive-haui-avs.daothangclash2803200.chatgpt.site`
- USB Device Bridge: `https://safedrive-haui-avs.daothangclash2803200.chatgpt.site/device-bridge`
- Direct APK: `https://safedrive-haui-avs.daothangclash2803200.chatgpt.site/downloads/SafeDrive-demo-unified-ac8c804.apk`
- Browser transport: HTTPS + WebUSB + ADB RSA; command surface is allowlisted to the SafeDrive telemetry broadcast.
- Local `http://127.0.0.1:3000`: retained as team fallback, not required for judges.

## Backend production

- Public URL: `https://safedrive-backend-165374511912.asia-southeast1.run.app`
- Canonical Cloud Run URL: `https://safedrive-backend-et637fqnsa-as.a.run.app`
- Revision: `safedrive-backend-00015-kfj`
- Traffic: `100%`
- Runtime backend SHA: `ac8c804831b9a4991e4ed46625b458c6d5fc95d0`
- Runtime and submission release use the same source SHA.
- `minScale=1`, `maxScale=1`
- `LLM_PROVIDER=vertex_ai`
- `LLM_MODEL=gemini-2.5-flash`
- `MEMORY_BACKEND=firestore`
- Health: `/health` → `status=ok`; readiness: `/ready` → `status=ready`.

## Test gate ngày 09/08/2026

- Android: `364 tests`, `0 failures`, `0 errors`, `0 skipped`.
- Backend: `355 passed`, `1 warning`.
- Android assembleDebug: `BUILD SUCCESSFUL`.
- Xiaomi install: `Success`, `lastUpdateTime=2026-08-09 10:57:16`.

## Hybrid LLM runtime

- Cloud production: Vertex AI `gemini-2.5-flash`, 13/13 live matrix.
- Local edge development host: Ollama `qwen2.5:7b-instruct-q4_K_M`, 13/13 live matrix.
- Jetson: compatible deployment target through the same Ollama HTTP provider; hardware validation pending.

## CarSky

- Blueprint: `Haui AVS` và `Haui AVS-SafeDrive`.
- Deployment: `Haui AVS-deploydeployment-1`, `Running 20/20 nodes ready`.
- IVI ADB: bằng chứng kết nối có trong `evidence/screenshots/01_carsky_deployment_20_of_20.png`.
- IVI runtime: `evidence/screenshots/17_carsky_ivi_safedrive_open.png` cho thấy Haui AVS Connected, SafeDrive Cockpit mở trong IVI Screen và các HvacCommand signals hiện diện.
- APK latest: artifact `safedrive-apk` version `0.0.6`.
